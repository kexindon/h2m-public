# SPDX-FileCopyrightText: 2024-present kexindon <gorkordkx@gmail.com>
#
# SPDX-License-Identifier: MIT
from .module import *