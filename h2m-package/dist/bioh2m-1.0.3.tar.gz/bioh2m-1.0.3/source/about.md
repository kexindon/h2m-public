# About H2M  

```{image} figures/h2m-logo-final.png  
:width: 280px
:align: left
```

Author: Kexin Dong

Email: gorkordkx@gmail.com

<a href='https://www.sanchezriveralab.com' target="_blank" rel="noopener noreferrer">Sánchez-Rivera Lab</a>

Massachusetts Institute of Technology Department of Biology

Koch Institute for Integrative Cancer Research   

## Version History   

### 1.0.0

First Release.

### 1.0.1 

Updated the tutorial file.

### 1.0.2 

Updated the class 5 input for reference and alternate sequences.  