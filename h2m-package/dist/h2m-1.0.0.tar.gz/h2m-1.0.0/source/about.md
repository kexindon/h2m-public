# About H2M  

```{image} figures/h2m-logo-final.png  
:width: 280px
:align: left
```

Author: Kexin Dong

Email: gorkordkx@gmail.com

Massachusetts Institute of Technology Department of Biology

Koch Institute for Integrative Cancer Research