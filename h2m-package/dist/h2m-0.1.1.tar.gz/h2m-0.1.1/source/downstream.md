# H2M Database Online Portal 

Downstream Genome Editing Librabry Design Tool 

## PEGG: Prime Editing Guide Generator  
[PEGG](https://pegg.readthedocs.io/en/latest/index.html) is a python package that designs prime editing guide RNAs (pegRNAs) and base editing guide RNAs (gRNAs) for use in precision genome editing.  