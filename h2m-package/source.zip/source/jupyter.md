# Jupyter Notebook Tutorial
```{image} figures/h2m-logo-final.png  
:width: 150px
:align: left
```
A jupyter notebook version of the H2M tutorial can be accessed <a href="https://github.com/kexindon/h2m-public/blob/main/h2m_package_tutorial.ipynb" target="_blank" rel="noopener noreferrer">here</a>:
